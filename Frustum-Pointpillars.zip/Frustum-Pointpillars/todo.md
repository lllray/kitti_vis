# TODO
* Add RGB Info
* Mask RCNN 2D detections
* Improve Mask RCNN / YOLO using pointcloud projection

# DONE
* Use external detection file for evaluation
* Add random noise for 2D bounding box when training
