# PointPillars Configs

The configuration files in these directories can be used to reproduce the results published in PointPillars.
