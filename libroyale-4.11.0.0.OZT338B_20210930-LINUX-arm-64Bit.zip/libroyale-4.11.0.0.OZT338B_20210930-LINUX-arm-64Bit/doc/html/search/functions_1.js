var searchData=
[
  ['describe_500',['describe',['../a00990.html#a27327afef4cf6a6c0b758d7fe925b426',1,'royale::IEvent']]]
];
