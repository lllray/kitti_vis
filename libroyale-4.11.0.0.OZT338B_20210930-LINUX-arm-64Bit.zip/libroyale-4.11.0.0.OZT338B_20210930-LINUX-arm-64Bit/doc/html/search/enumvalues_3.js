var searchData=
[
  ['data_5fnot_5ffound_738',['DATA_NOT_FOUND',['../a00137.html#a08d2011020d279958ab43e88aa954f83a113d2a552959871b7d7d5c29f9f2b774',1,'royale']]],
  ['deprecated1_739',['Deprecated1',['../a00137.html#aaf149d33f8e807f16de8ef9698397d39a2a9aba6f325f6dfd5c5ec922d520e646',1,'royale']]],
  ['deprecated2_740',['Deprecated2',['../a00137.html#aaf149d33f8e807f16de8ef9698397d39a97ce52f3676bb99da9a60c5ec49689af',1,'royale']]],
  ['deprecated3_741',['Deprecated3',['../a00137.html#aaf149d33f8e807f16de8ef9698397d39a53238e5b8b0a84f37acc9b4de06eaf50',1,'royale']]],
  ['deprecated4_742',['Deprecated4',['../a00137.html#aaf149d33f8e807f16de8ef9698397d39a05618e8afa79d61edcd2220dd2f1788d',1,'royale']]],
  ['depth_743',['Depth',['../a00137.html#ade70688fceca9ac2b41401bd8ed0119ca675056ad1441b6375b2c5abd48c27ef1',1,'royale']]],
  ['device_5falready_5finitialized_744',['DEVICE_ALREADY_INITIALIZED',['../a00137.html#a08d2011020d279958ab43e88aa954f83a95f1b5e72210ab9e32319f9f5130cd86',1,'royale']]],
  ['device_5fis_5fbusy_745',['DEVICE_IS_BUSY',['../a00137.html#a08d2011020d279958ab43e88aa954f83a28375078396aaa6663acd8f80cc286b4',1,'royale']]],
  ['device_5fnot_5finitialized_746',['DEVICE_NOT_INITIALIZED',['../a00137.html#a08d2011020d279958ab43e88aa954f83ac113642a58e4d7aa20c40d312372b82e',1,'royale']]],
  ['disconnected_747',['DISCONNECTED',['../a00137.html#a08d2011020d279958ab43e88aa954f83a99c8ce56e7ab246445d3b134724428f3',1,'royale']]],
  ['dutycycle_5fnot_5fsupported_748',['DUTYCYCLE_NOT_SUPPORTED',['../a00137.html#a08d2011020d279958ab43e88aa954f83a6389a464523be5f9e12507104e1fec6d',1,'royale']]]
];
