var searchData=
[
  ['hasdepth_154',['hasDepth',['../a00962.html#aa7c649e6a41f7174f0c908aa05adcd8a',1,'royale::DepthData']]],
  ['hasdepthdata_155',['hasDepthData',['../a01006.html#ab75e1d296447034b18f1808739416428',1,'royale::IExtendedData']]],
  ['hasintermediatedata_156',['hasIntermediateData',['../a01006.html#a5f175cd74e954c3aa8db67049445e7e2',1,'royale::IExtendedData']]],
  ['hasrawdata_157',['hasRawData',['../a01006.html#a5f112608b37613d8e0ac8eb7e9cdd8af',1,'royale::IExtendedData']]],
  ['height_158',['height',['../a00962.html#a81c9f8d0b8c3b49d770be14dbe9f0d37',1,'royale::DepthData::height()'],['../a00966.html#a81c9f8d0b8c3b49d770be14dbe9f0d37',1,'royale::DepthImage::height()'],['../a00970.html#a81c9f8d0b8c3b49d770be14dbe9f0d37',1,'royale::DepthIRImage::height()'],['../a01022.html#a81c9f8d0b8c3b49d770be14dbe9f0d37',1,'royale::IntermediateData::height()'],['../a01042.html#a81c9f8d0b8c3b49d770be14dbe9f0d37',1,'royale::IRImage::height()'],['../a01054.html#a81c9f8d0b8c3b49d770be14dbe9f0d37',1,'royale::RawData::height()']]]
];
