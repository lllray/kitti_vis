var searchData=
[
  ['rawdata_573',['RawData',['../a01054.html#a9586873066336885be0e4a48a80f40c8',1,'royale::RawData::RawData()'],['../a01054.html#a5279322e511fda362e81ee6bbbf7ac60',1,'royale::RawData::RawData(size_t rawVectorSize)']]],
  ['readregisters_574',['readRegisters',['../a00974.html#a2a67b1dfde68f1ad81300a04a1e2faae',1,'royale::ICameraDevice']]],
  ['registerdatalistener_575',['registerDataListener',['../a00974.html#a8db2c6fe77b49be6a6be238579e2fca9',1,'royale::ICameraDevice']]],
  ['registerdatalistenerextended_576',['registerDataListenerExtended',['../a00974.html#a1257180bf74ce801bc221d54a43c56e5',1,'royale::ICameraDevice']]],
  ['registerdepthimagelistener_577',['registerDepthImageListener',['../a00974.html#a6cc823ebcec871a1f3c9b3b26da9c188',1,'royale::ICameraDevice']]],
  ['registerdepthirimagelistener_578',['registerDepthIRImageListener',['../a00974.html#a7c5ff069ef103188062d2ebb0ec3f4fc',1,'royale::ICameraDevice']]],
  ['registereventlistener_579',['registerEventListener',['../a00954.html#aa3315701cb25383ab438a4f049181b32',1,'royale::CameraManager::registerEventListener()'],['../a00974.html#a43b9868077e54af9c5d458712136f329',1,'royale::ICameraDevice::registerEventListener()'],['../a01030.html#a543af844c74411d945857ce40d72f25b',1,'royale::IRecord::registerEventListener()']]],
  ['registerexposurelistener_580',['registerExposureListener',['../a00974.html#a6d69a6acf024840ee41bdc07846c73de',1,'royale::ICameraDevice::registerExposureListener(royale::IExposureListener *listener)=0'],['../a00974.html#a85c8cd7a2f0957d15152457091305ee9',1,'royale::ICameraDevice::registerExposureListener(royale::IExposureListener2 *listener)=0']]],
  ['registeririmagelistener_581',['registerIRImageListener',['../a00974.html#aa5e4e4fce36a660a450ed8af7b4d73ee',1,'royale::ICameraDevice']]],
  ['registerrecordlistener_582',['registerRecordListener',['../a00974.html#a4546ca824444b8fc9857d126c4dd3d49',1,'royale::ICameraDevice']]],
  ['registersparsepointcloudlistener_583',['registerSparsePointCloudListener',['../a00974.html#a0c6d07004c2f6f1c11222718ef8c6f77',1,'royale::ICameraDevice']]],
  ['registerstoplistener_584',['registerStopListener',['../a01038.html#a377bf5123e81e8acc8691a02c1ead6fd',1,'royale::IReplay']]],
  ['resetparameters_585',['resetParameters',['../a01030.html#a5c8c5368b37e0e1ee668a6b26a32b124',1,'royale::IRecord']]],
  ['resume_586',['resume',['../a01038.html#a6596cf9cc8befb8bce505a0cc4228180',1,'royale::IReplay']]]
];
