var searchData=
[
  ['variant_456',['Variant',['../a01062.html',1,'royale']]]
];
