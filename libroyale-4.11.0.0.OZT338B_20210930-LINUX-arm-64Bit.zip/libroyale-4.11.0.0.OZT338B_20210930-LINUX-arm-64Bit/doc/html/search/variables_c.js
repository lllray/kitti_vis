var searchData=
[
  ['rawdata_682',['rawData',['../a01054.html#aa9e98afc59eb87b8a984df102ea79f10',1,'royale::RawData']]],
  ['rawframecount_683',['rawFrameCount',['../a01054.html#a1547f2f871c0fd55000faf697af6bd0a',1,'royale::RawData']]]
];
