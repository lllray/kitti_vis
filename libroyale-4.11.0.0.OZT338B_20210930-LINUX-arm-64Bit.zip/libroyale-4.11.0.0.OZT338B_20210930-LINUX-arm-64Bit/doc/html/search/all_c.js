var searchData=
[
  ['off_246',['Off',['../a00137.html#aaf149d33f8e807f16de8ef9698397d39ad15305d7a4e34e02489c74a5ef542f36',1,'royale']]],
  ['onevent_247',['onEvent',['../a00994.html#aa8ca251cb2777e4bc2fe4515f812b0b6',1,'royale::IEventListener']]],
  ['onnewdata_248',['onNewData',['../a00978.html#aee2898e664f67e962e969739ea6b300b',1,'royale::IDepthDataListener::onNewData()'],['../a00982.html#ad0fe0bdc7924f6a0f9e87b1304b113c1',1,'royale::IDepthImageListener::onNewData()'],['../a00986.html#a85e9c5f40bb769102b1639404c78f02a',1,'royale::IDepthIRImageListener::onNewData()'],['../a01010.html#aa2f557a95380d05fa0a0ee6abf171630',1,'royale::IExtendedDataListener::onNewData()'],['../a01014.html#a56318ed332bcdd1942323e0eceda6af2',1,'royale::IIRImageListener::onNewData()'],['../a01046.html#aa7739847e0078a3aa5a56761c42ac720',1,'royale::ISparsePointCloudListener::onNewData()']]],
  ['onnewexposure_249',['onNewExposure',['../a00998.html#a40e2cf8c22417fc00709a041082bf634',1,'royale::IExposureListener::onNewExposure()'],['../a01002.html#adcfa03726aefb67c37e9e41906b6b7b2',1,'royale::IExposureListener2::onNewExposure()']]],
  ['onplaybackstopped_250',['onPlaybackStopped',['../a01026.html#a3ca0f144a02875852710aa788e7cf7a0',1,'royale::IPlaybackStopListener']]],
  ['onrecordingstopped_251',['onRecordingStopped',['../a01034.html#a3722aaac4b1ce8584ac561099e957eb6',1,'royale::IRecordStopListener']]],
  ['operator_20bool_252',['operator bool',['../a01030.html#aecd9240fe1fa34049e5998dd3dbc03c8',1,'royale::IRecord']]],
  ['operator_21_3d_253',['operator!=',['../a01062.html#ae901b85d9ab9ad883c1e8de41dd212ef',1,'royale::Variant']]],
  ['operator_3c_254',['operator&lt;',['../a01062.html#a19922fcd36f575d19731a286a1fa9e54',1,'royale::Variant']]],
  ['operator_3c_3c_255',['operator&lt;&lt;',['../a00137.html#a02da8df51210469fe33eb3f51d2b6611',1,'royale']]],
  ['operator_3d_256',['operator=',['../a00962.html#ad22042cbc054a31da40edb7604899276',1,'royale::DepthData::operator=()'],['../a01022.html#a6019b6f3d6a41abcead3179359deb8de',1,'royale::IntermediateData::operator=()']]],
  ['operator_3d_3d_257',['operator==',['../a01062.html#a4de4c475748369c7cf06b26578609971',1,'royale::Variant']]],
  ['out_5fof_5fbounds_258',['OUT_OF_BOUNDS',['../a00137.html#a08d2011020d279958ab43e88aa954f83a71e5e8b8caeedea08ea1f0e75143e047',1,'royale']]]
];
