var searchData=
[
  ['x_406',['x',['../a00958.html#ad0da36b2558901e21e7a30f6c227a45e',1,'royale::DepthPoint']]],
  ['xyzcpoints_407',['xyzcPoints',['../a01058.html#a4ce24a192e983040cfd3ee546ca08d05',1,'royale::SparsePointCloud']]]
];
