var searchData=
[
  ['timestamp_685',['timeStamp',['../a00962.html#ae79bd1a18ab6e0c28084edf8df849fd5',1,'royale::DepthData::timeStamp()'],['../a01022.html#ae79bd1a18ab6e0c28084edf8df849fd5',1,'royale::IntermediateData::timeStamp()'],['../a01054.html#ae79bd1a18ab6e0c28084edf8df849fd5',1,'royale::RawData::timeStamp()'],['../a00966.html#a8a591d341723df9496cda98e225b25b4',1,'royale::DepthImage::timestamp()'],['../a00970.html#a8a591d341723df9496cda98e225b25b4',1,'royale::DepthIRImage::timestamp()'],['../a01042.html#a8a591d341723df9496cda98e225b25b4',1,'royale::IRImage::timestamp()'],['../a01058.html#a8a591d341723df9496cda98e225b25b4',1,'royale::SparsePointCloud::timestamp()']]]
];
