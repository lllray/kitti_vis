var searchData=
[
  ['version_686',['version',['../a00962.html#aad880fc4455c253781e8968f2239d56f',1,'royale::DepthData::version()'],['../a01022.html#aad880fc4455c253781e8968f2239d56f',1,'royale::IntermediateData::version()']]]
];
