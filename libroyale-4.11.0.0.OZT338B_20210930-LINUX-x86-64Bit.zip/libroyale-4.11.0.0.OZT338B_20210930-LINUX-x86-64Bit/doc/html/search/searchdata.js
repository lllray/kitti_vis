var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuvwxyz~",
  1: "cdilrsv",
  2: "r",
  3: "cdefilprstv",
  4: "cdfghiloprstuvw~",
  5: "abcdefghimnprstvwxyz",
  6: "ps",
  7: "cefpstv",
  8: "abcdefgilmnoprstuw",
  9: "ar",
  10: "r",
  11: "i"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "defines",
  10: "groups",
  11: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Macros",
  10: "Modules",
  11: "Pages"
};

