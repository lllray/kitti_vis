var searchData=
[
  ['hasdepthdata_551',['hasDepthData',['../a01006.html#ab75e1d296447034b18f1808739416428',1,'royale::IExtendedData']]],
  ['hasintermediatedata_552',['hasIntermediateData',['../a01006.html#a5f175cd74e954c3aa8db67049445e7e2',1,'royale::IExtendedData']]],
  ['hasrawdata_553',['hasRawData',['../a01006.html#a5f112608b37613d8e0ac8eb7e9cdd8af',1,'royale::IExtendedData']]]
];
