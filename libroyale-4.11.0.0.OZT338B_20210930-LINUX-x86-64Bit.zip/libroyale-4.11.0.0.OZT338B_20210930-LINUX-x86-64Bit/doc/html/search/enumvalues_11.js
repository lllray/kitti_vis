var searchData=
[
  ['wrong_5fdata_5fformat_5ffound_858',['WRONG_DATA_FORMAT_FOUND',['../a00137.html#a08d2011020d279958ab43e88aa954f83aacc2fff8761448264a43d967f18b0c06',1,'royale']]]
];
