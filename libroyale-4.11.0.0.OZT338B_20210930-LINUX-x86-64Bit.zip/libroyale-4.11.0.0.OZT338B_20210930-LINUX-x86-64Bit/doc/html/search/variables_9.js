var searchData=
[
  ['modulationfrequencies_674',['modulationFrequencies',['../a01022.html#a8a090127b341725e9898ecf42321e182',1,'royale::IntermediateData::modulationFrequencies()'],['../a01054.html#a8a090127b341725e9898ecf42321e182',1,'royale::RawData::modulationFrequencies()']]]
];
