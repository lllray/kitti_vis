var searchData=
[
  ['slave_829',['SLAVE',['../a00137.html#aa534ed76b07c3983382a53e00e53e94aa79e19bc2ac33d6c81272024561992f37',1,'royale']]],
  ['smoothingalpha_5ffloat_830',['SmoothingAlpha_Float',['../a00137.html#a939253c294a92fd4eaf824f71f3985caa20b41f2ca104801595abb74fc90704bc',1,'royale']]],
  ['smoothingfilterresetthreshold_5ffloat_831',['SmoothingFilterResetThreshold_Float',['../a00137.html#a939253c294a92fd4eaf824f71f3985caabc8e249ec8b61c1fc257b10eb39ea469',1,'royale']]],
  ['smoothingfiltertype_5fint_832',['SmoothingFilterType_Int',['../a00137.html#a939253c294a92fd4eaf824f71f3985caaef0aef0f38dd687e7f0bb7c0ffb73044',1,'royale']]],
  ['spectre_5fnot_5finitialized_833',['SPECTRE_NOT_INITIALIZED',['../a00137.html#a08d2011020d279958ab43e88aa954f83af5b11523579e950a919ce57067b26030',1,'royale']]],
  ['spectreprocessingtype_5fint_834',['SpectreProcessingType_Int',['../a00137.html#a939253c294a92fd4eaf824f71f3985caa4617bf465eb868a3031d8100a68feb25',1,'royale']]],
  ['straylightthreshold_5ffloat_835',['StraylightThreshold_Float',['../a00137.html#a939253c294a92fd4eaf824f71f3985caa149cf5eea31b2dc751afb282cc4392d2',1,'royale']]],
  ['success_836',['SUCCESS',['../a00137.html#a08d2011020d279958ab43e88aa954f83ad0749aaba8b833466dfcbb0428e4f89c',1,'royale']]]
];
