var searchData=
[
  ['phasenoisethresh_5ffloat_803',['PhaseNoiseThresh_Float',['../a00137.html#a939253c294a92fd4eaf824f71f3985caa5d0e8cc815f6b85657cd07d36c1ba8ca',1,'royale']]]
];
