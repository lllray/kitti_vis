var searchData=
[
  ['width_687',['width',['../a00962.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::DepthData::width()'],['../a00966.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::DepthImage::width()'],['../a00970.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::DepthIRImage::width()'],['../a01022.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::IntermediateData::width()'],['../a01042.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::IRImage::width()'],['../a01054.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::RawData::width()']]]
];
